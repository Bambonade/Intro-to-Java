package edu.wctc;

public interface Exitable {
    public String exit(Player player);
}

package edu.wctc;

public interface Interactable {
    public String interact(Player player);
}

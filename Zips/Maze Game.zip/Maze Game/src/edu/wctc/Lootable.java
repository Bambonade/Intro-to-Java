package edu.wctc;

public interface Lootable {
    public String loot(Player player);
}
